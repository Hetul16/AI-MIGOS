// firebase/config.jsx
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// For development, you can hardcode the config or use import.meta.env for Vite
const firebaseConfig = {
  apiKey: import.meta.env?.VITE_FIREBASE_API_KEY || "",
  authDomain: import.meta.env?.VITE_FIREBASE_AUTH_DOMAIN || "ai--2f.com",
  projectId: import.meta.env?.VITE_FIREBASE_PROJECT_ID || "ai-2f390",
  storageBucket: import.meta.env?.VITE_FIREBASE_STORAGE_BUCKET || "ai-mebasestorage.app",
  messagingSenderId: import.meta.env?.VITE_FIREBASE_MESSAGING_SENDER_ID || "57761736",
  appId: import.meta.env?.VITE_FIREBASE_APP_ID || "1:5773851b342373f07aecf693d",
  measurementId: import.meta.env?.VITE_FIREBASE_MEASUREMENT_ID || "G-",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Firebase Authentication
export const auth = getAuth(app);

// Google Auth Provider
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

// Firestore Database
export const db = getFirestore(app);

export default app;